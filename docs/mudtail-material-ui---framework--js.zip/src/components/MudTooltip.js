// Vanilla JS MudTooltip Helper with GSAP
import gsap from 'gsap';

export function attachTooltip(element, text, position = 'top') {
  if (!element || !text) return;

  let tooltipEl = null;

  element.addEventListener('mouseenter', () => {
    tooltipEl = document.createElement('div');
    tooltipEl.className = 'mud-tooltip';
    tooltipEl.innerText = text;
    document.body.appendChild(tooltipEl);

    const rect = element.getBoundingClientRect();
    const tipRect = tooltipEl.getBoundingClientRect();

    let top = 0;
    let left = 0;

    if (position === 'top') {
      top = rect.top - tipRect.height - 8;
      left = rect.left + rect.width / 2 - tipRect.width / 2;
    } else if (position === 'bottom') {
      top = rect.bottom + 8;
      left = rect.left + rect.width / 2 - tipRect.width / 2;
    } else if (position === 'left') {
      top = rect.top + rect.height / 2 - tipRect.height / 2;
      left = rect.left - tipRect.width - 8;
    } else if (position === 'right') {
      top = rect.top + rect.height / 2 - tipRect.height / 2;
      left = rect.right + 8;
    }

    tooltipEl.style.top = `${Math.max(4, top)}px`;
    tooltipEl.style.left = `${Math.max(4, left)}px`;

    gsap.fromTo(
      tooltipEl,
      { opacity: 0, y: position === 'top' ? 4 : position === 'bottom' ? -4 : 0 },
      { opacity: 1, y: 0, duration: 0.18, ease: 'power2.out', onStart: () => tooltipEl.classList.add('visible') }
    );
  });

  element.addEventListener('mouseleave', () => {
    if (tooltipEl) {
      gsap.to(tooltipEl, {
        opacity: 0,
        duration: 0.15,
        onComplete: () => {
          if (tooltipEl) {
            tooltipEl.remove();
            tooltipEl = null;
          }
        },
      });
    }
  });
}
