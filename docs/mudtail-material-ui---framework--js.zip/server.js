// Node.js Express Server running Vite middleware with pure JavaScript modules
import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // API Endpoints
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      runtime: 'node.js',
      version: process.version,
      modules: 'pure javascript es-modules',
      cssFramework: 'sass (scss) on vite',
      animation: 'gsap 3',
    });
  });

  app.post('/api/theme/export', (req, res) => {
    const { primary, secondary, borderRadius } = req.body || {};
    res.json({
      success: true,
      scssVariables: {
        primary: primary || '#594ae2',
        secondary: secondary || '#ff4081',
        borderRadius: `${borderRadius || 4}px`,
      },
      timestamp: new Date().toISOString(),
    });
  });

  // Mount Vite middleware in development
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true, port: 3000, host: '0.0.0.0' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MudTail] Node.js Vanilla JS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
